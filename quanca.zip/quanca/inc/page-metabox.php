<?php
// Post-Type = Class
if( class_exists( 'CSF' ) ) {

  //
  // Set a unique slug-like ID
  $prefix = 'my_page_options';

  //
  // Create a metabox
  CSF::createMetabox( $prefix, array(
    'title'     => 'Page Options',
    'post_type' => 'page',
  ) );

  //
  // Create a section
    CSF::createSection( $prefix, array(
        'fields' => array(
            array(
                'id'        => 'opt-pag-bg',
                'type'  => 'upload',
                'title'     => 'ADD Page Background',
                
            ),
        
        ))
    );
}
