<?php
// Post-Type = Schedule
if( class_exists( 'CSF' ) ) {

  //
  // Set a unique slug-like ID
  $prefix = 'my_schedule_options';

  //
  // Create a metabox
  CSF::createMetabox( $prefix, array(
    'title'     => 'My Schedule Options',
    'post_type' => 'schedule',
  ) );

  //
  // Create a section
    CSF::createSection( $prefix, array(
                'title'     => 'ADD Schedule Details',
                'fields'    => array(
                    array(
                        'id'          => 'date-select',
                        'type'        => 'select',
                        'title'       => 'Select Date',
                        'placeholder' => 'Select a date',
                        'options'     => array(
                        'sunday'  => 'SUNDAY',
                        'monday'  => 'MONDAY',
                        'tuesday'  => 'TUESDAY',
                        'wednesday'  => 'WEDNESDAY',
                        'thursday'  => 'THURSDAY',
                        'friday'  => 'FRIDAY',
                        'saturday'  => 'SATURDAY',
                        ),
                    ),
                    array(
                        'id'    => 'schedule-from',
                        'type'  => 'text',
                        'title' => 'From'
                    ),
                    array(
                        'id'    => 'schedule-to',
                        'type'  => 'text',
                        'title' => 'To'
                    ),
                    array(
                        'id'    => 'schedule-desc',
                        'type'  => 'text',
                        'title' => 'Description'
                    ),
                )
            ),
        );
}
