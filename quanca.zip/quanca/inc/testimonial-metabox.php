<?php
// Post-Type = Schedule
if( class_exists( 'CSF' ) ) {

  //
  // Set a unique slug-like ID
  $prefix = 'my_testimonial_options';

  //
  // Create a metabox
  CSF::createMetabox( $prefix, array(
    'title'     => 'My Testimonial Options',
    'post_type' => 'testimonial',
  ) );

  //
  // Create a section
    CSF::createSection( $prefix, array(
                'fields'    => array(
                    array(
                        'id'    => 'test-name',
                        'type'  => 'text',
                        'title' => 'Name'
                    ),
                    array(
                        'id'    => 'test-desc',
                        'type'  => 'textarea',
                        'title' => 'Text'
                    ),
                    array(
                        'id'    => 'test-img',
                        'type'  => 'upload',
                        'title' => 'Image'
                    ),
                    array(
                        'id'    => 'test-rating',
                        'type'  => 'select',
                        'title' => 'Rating',
                        'options'     => array(
                            '1'  => 'One Star',
                            '2'  => 'Two Star',
                            '3'  => 'Three Star',
                            '4'  => 'Four Star',
                            '5'  => 'Five Star',
                        ),
                        'default'     => '5'
                    ),
                )
            ),
        );
}
