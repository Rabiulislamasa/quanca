<?php
// Post-Type = Class
if( class_exists( 'CSF' ) ) {

  //
  // Set a unique slug-like ID
  $prefix = 'my_post_options';

  //
  // Create a metabox
  CSF::createMetabox( $prefix, array(
    'title'     => 'My Class Options',
    'post_type' => 'class',
  ) );

  //
  // Create a section
    CSF::createSection( $prefix, array(
        'fields' => array(
            array(
                'id'        => 'opt-group-1',
                'type'      => 'group',
                'title'     => 'ADD CLASS EXTRA BEFORE CONTENT',
                'button_title'=>'ADD EXTRA',
                'fields'    => array(
                    array(
                        'id'    => 'opt-text',
                        'type'  => 'text',
                        'title' => 'Title'
                    ),
                    array(
                        'id'    => 'opt-text2',
                        'type'  => 'text',
                        'title' => 'Description'
                    ),
                )
            ),
        
            array(
                'id'        => 'opt-group-2',
                'type'      => 'group',
                'title'     => 'ADD CLASS EXTRA AFTER CONTENT',
                'button_title'=>'ADD EXTRA',
                'fields'    => array(
                    array(
                        'id'    => 'opt-text3',
                        'type'  => 'text',
                        'title' => 'Title'
                    ),
                    array(
                        'id'    => 'opt-text4',
                        'type'  => 'textarea',
                        'title' => 'Description'
                    ),
                    array(
                        'id'    => 'opt-upload-1',
                        'type'  => 'upload',
                        'title' => 'IMAGE/VIDEO',
                    ),
                )
            )
        ))
    );
}
