<?php 
if(class_exists('kirki')){
Kirki::add_config( 'theme_config_id', array(
	'capability'    => 'edit_theme_options',
	'option_type'   => 'theme_mod',
) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'upload',
		'settings'    => 'loder_logo',
		'label'       => esc_html__( 'Preloader Icon', 'quanca' ),
		'description' => esc_html__('White will be the best color', 'quanca'),
		'section'     => 'title_tagline',
	] );

	/**Header */
	Kirki::add_panel( 'header_panel_id', array(
		'priority'    => 5,
		'title'       => esc_html__( 'Header', 'quanca' ),
		
	) );
	Kirki::add_section( 'header_top_id', array(
		'title'          => esc_html__( 'Header Top', 'quanca' ),
		'panel'          => 'header_panel_id',
		'priority'       => 10,
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'header_top_setting',
		'label'       => esc_html__( 'Display Contact Descriptions On Top', 'quanca' ),
		'section'     => 'header_top_id',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );
	Kirki::add_section( 'header_details', array(
		'title'          => esc_html__( 'Email Phone & Location', 'quanca' ),
		'panel'          => 'header_panel_id',
		'priority'       => 12,
	) );
	
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'head_mail',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Email', 'quanca' ),
		'section'     => 'header_details',
	] );
	
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'head_phn',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Phone', 'quanca' ),
		'section'     => 'header_details',
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'head_loc',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Location', 'quanca' ),
		'section'     => 'header_details',
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'link',
		'settings'    => 'head_loc_link',
		'label'       => esc_html__( 'Location Link', 'quanca' ),
		'section'     => 'header_details',
	] );

	Kirki::add_section( 'header_button_id', array(
		'title'          => esc_html__( 'Header Button', 'quanca' ),
		'panel'          => 'header_panel_id',
		'priority'       => 15,
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'header_button_setting',
		'label'       => esc_html__( 'Display Button On Header', 'quanca' ),
		'section'     => 'header_button_id',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'button_title',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Button Title', 'quanca' ),
		'section'     => 'header_button_id',
		'active_callback'=>[
            [ 
                'setting' => 'header_button_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'button_link',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Button Link', 'quanca' ),
		'section'     => 'header_button_id',
		'active_callback'=>[
            [ 
                'setting' => 'header_button_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	Kirki::add_section( 'header_sidebar', array(
		'title'          => esc_html__( 'Sidebar', 'quanca' ),
		'panel'          => 'header_panel_id',
		'priority'       => 12,
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'textarea',
		'settings'    => 'head_words',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Some Words', 'quanca' ),
		'section'     => 'header_sidebar',
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'repeater',
		'label'       => esc_attr__( 'Image', 'quanca' ),
		'section'     => 'header_sidebar',
		'settings'    => 'header_sidebar_img',
		'row_label' => [
			'type'  => 'text',
			'value' => esc_html__( 'Image', 'quanca' ),
		],
		'fields' => [
			'side_img' => [
				'type'        => 'image',
				'label'       => esc_attr__( 'Select Image', 'quanca' ),
			],
			'choices'     => [
				'save_as' => 'id',
			],
		],
		
		'choices' => [
			'limit' => 2
		],
	] );
	/**Header End*/

	/**Class.php */
	Kirki::add_panel( 'class_panel_id', array(
		'priority'    => 25,
		'title'       => esc_html__( 'Class Page Customize Option', 'quanca' ),
		
	) );
	Kirki::add_section( 'class_top_bg', array(
		'title'          => esc_html__( 'Header Background', 'quanca' ),
		'panel'          => 'class_panel_id',
		'priority'       => 10,
		'active_callback' => function() {
			if(is_post_type_archive( 'class' )){
				return true;}}
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'background',
		'settings'    => 'class_background_setting',
		'label'       => esc_html__( 'Background Control', 'quanca' ),
		'section'     => 'class_top_bg',
		'default'     => [
			'background-color'      => 'rgba(20,20,20,.8)',
			'background-repeat'     => 'repeat',
			'background-position'   => 'center center',
			'background-size'       => 'cover',
			'background-attachment' => 'scroll',
		],
		'output' => array(
			array(
				'element'  => '#class_header',
				'property' => 'background',
			),
		),
		
	] );
	Kirki::add_section( 'class_page_title_desc', array(
		'title'          => esc_html__( 'Page Title & Description', 'quanca' ),
		'panel'          => 'class_panel_id',
		'priority'       => 15,
		'active_callback' => function() {
			if(is_post_type_archive('class')){
				return true;}},
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'class_des_setting',
		'label'       => esc_html__( 'Display Contact Descriptions On Top', 'quanca' ),
		'section'     => 'class_page_title_desc',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'class_page_title',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Title', 'quanca' ),
		'section'     => 'class_page_title_desc',
		'active_callback'=>[
            [ 
                'setting' => 'class_des_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'textarea',
		'settings'    => 'class_page_desc',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Description', 'quanca' ),
		'section'     => 'class_page_title_desc',
		'active_callback'=>[
            [ 
                'setting' => 'class_des_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	/**End Class.php */

	/**schedule.php */
	Kirki::add_panel( 'schedule_panel_id', array(
		'priority'    => 25,
		'title'       => esc_html__( 'Schedule Page', 'quanca' ),
		
	) );
	Kirki::add_section( 'schedule_top_bg', array(
		'title'          => esc_html__( 'Header Background', 'quanca' ),
		'panel'          => 'schedule_panel_id',
		'priority'       => 10,
		'active_callback' => function() {
			if(is_post_type_archive('schedule')){
				return true;}},
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'background',
		'settings'    => 'schedule_background_setting',
		'label'       => esc_html__( 'Background Control', 'quanca' ),
		'section'     => 'schedule_top_bg',
		'default'     => [
			'background-color'      => 'rgba(20,20,20,.8)',
			'background-image'      => '',
			'background-repeat'     => 'repeat',
			'background-position'   => 'center center',
			'background-size'       => 'cover',
			'background-attachment' => 'scroll',
		],
		'output' => array(
			array(
				'element'  => '#schedule_header',
				'property' => 'background',
			),
		),
		
	] );
	Kirki::add_section( 'schedule_page_title_desc', array(
		'title'          => esc_html__( 'Page Title & Description', 'quanca' ),
		'panel'          => 'schedule_panel_id',
		'priority'       => 15,
		'active_callback' => function() {
			if(is_post_type_archive('schedule')){
				return true;}},
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'schedule_des_setting',
		'label'       => esc_html__( 'Display Contact Descriptions On Top', 'quanca' ),
		'section'     => 'schedule_page_title_desc',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'schedule_page_title',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Title', 'quanca' ),
		'section'     => 'schedule_page_title_desc',
		'active_callback'=>[
            [ 
                'setting' => 'schedule_des_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'textarea',
		'settings'    => 'schedule_page_desc',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Description', 'quanca' ),
		'section'     => 'schedule_page_title_desc',
		'active_callback'=>[
            [ 
                'setting' => 'schedule_des_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	
	Kirki::add_panel( 'schedule_img_panel_id', array(
		'priority'    => 30,
		'title'       => esc_html__( 'Schedule Image For Every Date', 'quanca' ),
		
	) );
	Kirki::add_section( 'schedule_img_monday', array(
		'title'          => esc_html__( 'Monday', 'quanca' ),
		'panel'          => 'schedule_img_panel_id',
		'priority'       => 15,
		'active_callback' => function() {
			if(is_post_type_archive('schedule')){
				return true;}},
	) );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'image',
		'settings'    => 'schedule_monday_img',
		'label'       => esc_html__( 'Image For Monday', 'quanca' ),
		'section'     => 'schedule_img_monday',
		
	] );
	Kirki::add_section( 'schedule_img_tuesday', array(
		'title'          => esc_html__( 'Tuesday', 'quanca' ),
		'panel'          => 'schedule_img_panel_id',
		'priority'       => 15,
		'active_callback' => function() {
			if(is_post_type_archive('schedule')){
				return true;}},
	) );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'image',
		'settings'    => 'schedule_tuesday_img',
		'label'       => esc_html__( 'Image For Tuesday', 'quanca' ),
		'section'     => 'schedule_img_tuesday',
		
	] );
	Kirki::add_section( 'schedule_img_wednesday', array(
		'title'          => esc_html__( 'Wednesday', 'quanca' ),
		'panel'          => 'schedule_img_panel_id',
		'priority'       => 15,
		'active_callback' => function() {
			if(is_post_type_archive('schedule')){
				return true;}},
	) );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'image',
		'settings'    => 'schedule_wednesday_img',
		'label'       => esc_html__( 'Image For Wednesday', 'quanca' ),
		'section'     => 'schedule_img_wednesday',
		
	] );
	Kirki::add_section( 'schedule_img_thursday', array(
		'title'          => esc_html__( 'Thursday', 'quanca' ),
		'panel'          => 'schedule_img_panel_id',
		'priority'       => 15,
		'active_callback' => function() {
			if(is_post_type_archive('schedule')){
				return true;}},
	) );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'image',
		'settings'    => 'schedule_thursday_img',
		'label'       => esc_html__( 'Image For Thursday', 'quanca' ),
		'section'     => 'schedule_img_thursday',
		
	] );
	Kirki::add_section( 'schedule_img_friday', array(
		'title'          => esc_html__( 'Friday', 'quanca' ),
		'panel'          => 'schedule_img_panel_id',
		'priority'       => 15,
		'active_callback' => function() {
			if(is_post_type_archive('schedule')){
				return true;}},
	) );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'image',
		'settings'    => 'schedule_friday_img',
		'label'       => esc_html__( 'Image For Friday', 'quanca' ),
		'section'     => 'schedule_img_friday',
		
	] );
	Kirki::add_section( 'schedule_img_saturday', array(
		'title'          => esc_html__( 'Saturday', 'quanca' ),
		'panel'          => 'schedule_img_panel_id',
		'priority'       => 15,
		'active_callback' => function() {
			if(is_post_type_archive('schedule')){
				return true;}},
	) );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'image',
		'settings'    => 'schedule_saturday_img',
		'label'       => esc_html__( 'Image For Saturday', 'quanca' ),
		'section'     => 'schedule_img_saturday',
		
	] );
	Kirki::add_section( 'schedule_img_sunday', array(
		'title'          => esc_html__( 'Sunday', 'quanca' ),
		'panel'          => 'schedule_img_panel_id',
		'priority'       => 15,
		'active_callback' => function() {
			if(is_post_type_archive('schedule')){
				return true;}},
	) );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'image',
		'settings'    => 'schedule_sunday_img',
		'transport'	=> 'postMessage',
		'label'       => esc_html__( 'Image For Sunday', 'quanca' ),
		'section'     => 'schedule_img_sunday',
		
	] );
	/**End schedule.php */
	

	/**index.php */
	Kirki::add_panel( 'index_panel_id', array(
		'priority'    => 25,
		'title'       => esc_html__( 'Page Customize Option', 'quanca' ),
		
	) );
	Kirki::add_section( 'index_top_bg', array(
		'title'          => esc_html__( 'Header Background', 'quanca' ),
		'panel'          => 'index_panel_id',
		'priority'       => 10,
		'active_callback' => function() {
			if(is_front_page('index.php')){
				return true;}},
		//  
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'background',
		'settings'    => 'index_background_setting',
		'label'       => esc_html__( 'Background Control', 'quanca' ),
		'section'     => 'index_top_bg',
		'default'     => [
			'background-color'      => 'rgba(20,20,20,.8)',
			'background-image'      => '',
			'background-repeat'     => 'repeat',
			'background-position'   => 'center center',
			'background-size'       => 'cover',
			'background-attachment' => 'scroll',
		],
		'output' => array(
			array(
				'element'  => '#index_header',
				'property' => 'background',
			),
		),
		
	] );
	Kirki::add_section( 'index_page_title_desc', array(
		'title'          => esc_html__( 'Page Title & Description', 'quanca' ),
		'panel'          => 'index_panel_id',
		'priority'       => 15,
		'active_callback' => function() {
			if(is_front_page('index.php')){
				return true;}}
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'index_des_setting',
		'label'       => esc_html__( 'Display Contact Descriptions On Top', 'quanca' ),
		'section'     => 'index_page_title_desc',
		'transport'   => 'postMessage',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'index_page_title',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Title', 'quanca' ),
		'section'     => 'index_page_title_desc',
		'active_callback'=>[
            [ 
                'setting' => 'index_des_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'textarea',
		'settings'    => 'index_page_desc',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Description', 'quanca' ),
		'section'     => 'index_page_title_desc',
		'active_callback'=>[
            [ 
                'setting' => 'index_des_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	/**End index.php */
	

	/**about.php */
	Kirki::add_panel( 'about_panel_id', array(
		'priority'    => 30,
		'title'       => esc_html__( 'About Page Customization', 'quanca' ),
		
	) );
	Kirki::add_section( 'about_section_id', array(
		'title'          => esc_html__( 'Description For Us', 'quanca' ),
		'panel'          => 'about_panel_id',
		'priority'       => 0,
		'active_callback' => function() {
			if(is_page_template('about.php')){
				return true;}},
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'about_desc_stting',
		'label'       => esc_html__( 'Display Description Section', 'quanca' ),
		'section'     => 'about_section_id',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'about_des_small_title',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Small Title', 'quanca' ),
		'section'     => 'about_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'about_desc_stting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'about_des_big_title',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Big Title', 'quanca' ),
		'section'     => 'about_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'about_desc_stting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'textarea',
		'settings'    => 'about_des',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Descriptions', 'quanca' ),
		'section'     => 'about_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'about_desc_stting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'image',
		'settings'    => 'about_img',
		'label'       => esc_html__( 'Descriptions Image', 'quanca' ),
		'section'     => 'about_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'about_desc_stting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );

	Kirki::add_section( 'about_history_section_id', array(
		'title'          => esc_html__( 'Our Working History', 'quanca' ),
		'panel'          => 'about_panel_id',
		'priority'       => 10,
		'active_callback' => function() {
			if(is_page_template('about.php')){
				return true;}},
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'about_workhistory_stting',
		'label'       => esc_html__( 'Display Work History Section', 'quanca' ),
		'section'     => 'about_history_section_id',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'repeater',
		'label'       => esc_attr__( 'Our Work History', 'quanca' ),
		'section'     => 'about_history_section_id',
		'row_label' => [
			'type'  => 'field',
			'value' => esc_html__( 'Add Work Details', 'quanca' ),
			'field' => 'link_text',
		],
		'button_label' => esc_html__("Add new", 'quanca' ),
		
		'settings'    => 'my_work_repeater',
		'fields' => [
			'work_title' => [
				'type'        => 'text',
				'label'       => esc_attr__( 'Title', 'quanca' ),
			],
			'work_number' => [
				'type'        => 'number',
				'label'       => esc_attr__( 'Number Of Work', 'quanca' ),
			],
			'work_icon' => [
				'type'        => 'image',
				'label'       => esc_attr__( 'Icon Of Work', 'quanca' ),
			],
		],
		
		'choices' => [
			'limit' => 3
		],
		'active_callback'=>[
            [ 
                'setting' =>'about_workhistory_stting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );

	Kirki::add_section( 'about_trening_section_id', array(
		'title'          => esc_html__( 'Training Description', 'quanca' ),
		'panel'          => 'about_panel_id',
		'priority'       => 20,
		'active_callback' => function() {
			if(is_page_template('about.php')){
				return true;}},
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'about_training_desc_stting',
		'label'       => esc_html__( 'Display Description Section', 'quanca' ),
		'section'     => 'about_trening_section_id',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'about_training_small_title',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Small Title', 'quanca' ),
		'section'     => 'about_trening_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'about_training_desc_stting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'about_training_big_title',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Big Title', 'quanca' ),
		'section'     => 'about_trening_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'about_training_desc_stting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'repeater',
		'label'       => esc_attr__( 'Our Training', 'quanca' ),
		'priority'       => 1000,
		'section'     => 'about_trening_section_id',
		'row_label' => [
			'type'  => 'field',
			'value' => esc_html__( 'Add Training Details', 'quanca' ),
			'field' => 'link_text',
		],
		'button_label' => esc_html__("Add new", 'quanca' ),
	
		'settings'    => 'my_work_his_repeater',
		'fields' => [
			'trainig_title' => [
				'type'        => 'text',
				'label'       => esc_attr__( 'Title', 'quanca' ),
			],
			'training_dec' => [
				'type'        => 'text',
				'label'       => esc_attr__( 'Description', 'quanca' ),
			],
			'training_link' => [
				'type'        => 'link',
				'label'       => esc_attr__( 'Related Post Links', 'quanca' ),
			],
			'training_img' => [
				'type'        => 'image',
				'label'       => esc_attr__( 'Image', 'quanca' ),
			],
		],
		'choices' => [
			'limit' => 6
		],
		'active_callback'=>[
            [ 
                'setting' =>'about_training_desc_stting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );


	Kirki::add_section( 'about_qu_section_id', array(
		'title'          => esc_html__( 'Question, Answer & Services', 'quanca' ),
		'panel'          => 'about_panel_id',
		'priority'       => 20,
		'active_callback' => function() {
			if(is_page_template('about.php')){
				return true;}},
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'about_qu_desc_stting',
		'label'       => esc_html__( 'Display Question, Answer & Services Section', 'quanca' ),
		'section'     => 'about_qu_section_id',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'about_qu_stting',
		'label'       => esc_html__( 'Question', 'quanca' ),
		'section'     => 'about_qu_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'about_qu_desc_stting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'textarea',
		'settings'    => 'about_ans_stting',
		'label'       => esc_html__( 'Answer', 'quanca' ),
		'section'     => 'about_qu_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'about_qu_desc_stting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'about_sr_title_stting',
		'label'       => esc_html__( 'Services Title', 'quanca' ),
		'section'     => 'about_qu_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'about_qu_desc_stting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'about_sr_sb_title_stting',
		'label'       => esc_html__( 'Services Sub Title', 'quanca' ),
		'section'     => 'about_qu_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'about_qu_desc_stting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'repeater',
		'label'       => esc_attr__( 'Our Services', 'quanca' ),
		'priority'       => 1000,
		'section'     => 'about_qu_section_id',
		'row_label' => [
			'type'  => 'field',
			'value' => esc_html__( 'Add Services', 'quanca' ),
			'field' => 'link_text',
		],
		'button_label' => esc_html__("Add new", 'quanca' ),
	
		'settings'    => 'my_service_repeater',
		'fields' => [
			'ser_title' => [
				'type'        => 'text',
				'label'       => esc_attr__( 'Our Service', 'quanca' ),
			],
			
		],
		'active_callback'=>[
            [ 
                'setting' =>'about_qu_desc_stting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );



	Kirki::add_section( 'about_vid_section_id', array(
		'title'          => esc_html__( 'Video', 'quanca' ),
		'panel'          => 'about_panel_id',
		'priority'       => 20,
		'active_callback' => function() {
			if(is_page_template('about.php')){
				return true;}},
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'about_vid_desc_stting',
		'label'       => esc_html__( 'Display Video Section', 'quanca' ),
		'section'     => 'about_vid_section_id',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'upload',
		'settings'    => 'about_vid_stting',
		'label'       => esc_html__( 'ADD VIDEO', 'quanca' ),
		'section'     => 'about_vid_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'about_vid_desc_stting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	
	Kirki::add_section( 'team_section_id', array(
		'title'          => esc_html__( 'Our Team Details', 'quanca' ),
		'panel'          => 'about_panel_id',
		'priority'       => 30,
		'active_callback' => function() {
			if(is_page_template('about.php')){
				return true;}},
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'team_stting',
		'label'       => esc_html__( 'Display Work History Section', 'quanca' ),
		'section'     => 'team_section_id',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'team_sr_title_stting',
		'label'       => esc_html__( 'Team Section Sub  Title', 'quanca' ),
		'section'     => 'team_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'team_stting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'team_title_stting',
		'label'       => esc_html__( 'Team Section Title', 'quanca' ),
		'section'     => 'team_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'team_stting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'repeater',
		'label'       => esc_attr__( 'Our Trainers', 'quanca' ),
		'section'     => 'team_section_id',
		'row_label' => [
			'type'  => 'field',
			'value' => esc_html__( 'Add Trainers Details', 'quanca' ),
			'field' => 'link_text',
		],
		'button_label' => esc_html__("Add New Trainers Details", 'quanca' ),
	
		'settings'    => 'team_repeater',
		'fields' => [
			'member_name' => [
				'type'        => 'text',
				'label'       => esc_attr__( 'Name', 'quanca' ),
			],
			'member_position' => [
				'type'        => 'text',
				'label'       => esc_attr__( 'Position', 'quanca' ),
			],
			'member_description' => [
				'type'        => 'textarea',
				'label'       => esc_attr__( 'Description', 'quanca' ),
			],
			'member_image' => [
				'type'        => 'image',
				'label'       => esc_attr__( 'Member Image', 'quanca' ),
			],
			'fb_link' => [
				'type'        => 'link',
				'label'       => esc_attr__( 'Facebook Profile', 'quanca' ),
			],
			'twitter_link' => [
				'type'        => 'link',
				'label'       => esc_attr__( 'Twitter Profile', 'quanca' ),
			],
			'instagram_link' => [
				'type'        => 'link',
				'label'       => esc_attr__( 'Instagram Profile', 'quanca' ),
			],

		],
		'active_callback'=>[
            [ 
                'setting' =>'team_stting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );

	
	Kirki::add_section( 'about_smbanner_section_id', array(
		'title'          => esc_html__( 'Banner', 'quanca' ),
		'panel'          => 'about_panel_id',
		'priority'       => 40,
		'active_callback' => function() {
			if(is_page_template('about.php')){
				return true;}},
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'about_smbanner_desc_stting',
		'label'       => esc_html__( 'Display Question, Answer & Services Section', 'quanca' ),
		'section'     => 'about_smbanner_section_id',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'image',
		'settings'    => 'about_banner_img',
		// 'transport'   => 'postMessage',
		'label'       => esc_html__( 'Banner Image', 'quanca' ),
		'section'     => 'about_smbanner_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'about_smbanner_desc_stting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'about_banner_title',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Banner Title', 'quanca' ),
		'section'     => 'about_smbanner_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'about_smbanner_desc_stting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'textarea',
		'settings'    => 'about_banner_des',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Banner Description', 'quanca' ),
		'section'     => 'about_smbanner_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'about_smbanner_desc_stting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'about_btn_title',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Button Title', 'quanca' ),
		'section'     => 'about_smbanner_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'about_smbanner_desc_stting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'link',
		'settings'    => 'about_btn_link',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Bitton Link', 'quanca' ),
		'section'     => 'about_smbanner_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'about_smbanner_desc_stting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );

	

	/**about.php */


	/**contact.php */
	Kirki::add_panel( 'contact_panel_id', array(
		'priority'    => 30,
		'title'       => esc_html__( 'Contact Page Customization', 'quanca' ),
		
	) );
	Kirki::add_section( 'contact_section_id', array(
		'title'          => esc_html__( 'Contact Information', 'quanca' ),
		'panel'          => 'contact_panel_id',
		'priority'       => 0,
		'active_callback' => function() {
			if(is_page_template('contact.php')){
				return true;}},
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'contact_title',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Contact Title', 'quanca' ),
		'section'     => 'contact_section_id',
		
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'contact_desc',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Contact Description', 'quanca' ),
		'section'     => 'contact_section_id',
		
	] );
	
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'repeater',
		'label'       => esc_attr__( 'Contact Way', 'quanca' ),
		'section'     => 'contact_section_id',
		'row_label' => [
			'type'  => 'field',
			'value' => esc_html__( 'Add Contact Details', 'quanca' ),
			'field' => 'link_text',
		],
		'button_label' => esc_html__("Add New Contact Details", 'quanca' ),
	
		'settings'    => 'contact_repeater',
		'fields' => [
			'contact_name' => [
				'type'        => 'text',
				'label'       => esc_attr__( 'Title', 'quanca' ),
			],
			'contact_desc' => [
				'type'        => 'text',
				'label'       => esc_attr__( 'Description', 'quanca' ),
			],

		],
	] );
	Kirki::add_section( 'contact_time_id', array(
		'title'          => esc_html__( 'Contact Time', 'quanca' ),
		'panel'          => 'contact_panel_id',
		'priority'       => 0,
		'active_callback' => function() {
			if(is_page_template('contact.php')){
				return true;}},
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'contact_time_setting',
		'label'       => esc_html__( 'Display Contact Time For Everydays', 'quanca' ),
		'section'     => 'contact_time_id',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );
	
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'repeater',
		'label'       => esc_attr__( 'Contact Time For Everydays', 'quanca' ),
		'section'     => 'contact_time_id',
		'row_label' => [
			'type'  => 'field',
			'value' => esc_html__( 'Add Day And Time', 'quanca' ),
			'field' => 'link_text',
		],
		'button_label' => esc_html__("Add Next Day & Time", 'quanca' ),
	
		'settings'    => 'time_repeater',
		'fields' => [
			'contact_day' => [
				'type'        => 'text',
				'label'       => esc_attr__( 'Day', 'quanca' ),
			],
			'contact_from' => [
				'type'        => 'text',
				'label'       => esc_attr__( 'From', 'quanca' ),
			],
			'contact_to' => [
				'type'        => 'text',
				'label'       => esc_attr__( 'To', 'quanca' ),
			],

		],
		'active_callback'=>[
            [ 
                'setting' =>'contact_time_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	Kirki::add_section( 'contact_map', array(
		'title'          => esc_html__( 'Location', 'quanca' ),
		'panel'          => 'contact_panel_id',
		'priority'       => 100,
		
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'link',
		'settings'    => 'map_link',
		'label'       => esc_html__( 'Location on Google Map', 'quanca' ),
		'description' => esc_html__( 'Please input url from google map embed code', 'quanca' ),
		'section'     => 'contact_map',
		'active_callback' => function() {
			if(is_page_template('contact.php')){
				return true;}},
		
	] );
	/**contact.php */

	/**homepage.php */

	/**homepage.php */
	Kirki::add_panel( 'home_panel_id', array(
		'priority'    => 20,
		'title'       => esc_html__( 'Homepage Template Customization', 'quanca' ),
		
	) );
	Kirki::add_section( 'routine_section_id', array(
		'title'          => esc_html__( 'Some Routine', 'quanca' ),
		'panel'          => 'home_panel_id',
		'priority'       => 10,
		'active_callback' => function() {
			if(is_page_template('homepage.php')){
				return true;}},
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'routine_setting',
		'label'       => esc_html__( 'Display Some Routine', 'quanca' ),
		'section'     => 'routine_section_id',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'routine_title_setting',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Some Routine Section Title', 'quanca' ),
		'section'     => 'routine_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'routine_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
		
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'textarea',
		'settings'    => 'routine_desc_setting',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Some Routine Section Description', 'quanca' ),
		'section'     => 'routine_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'routine_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
		
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'repeater',
		'label'       => esc_attr__( 'Routine Details', 'quanca' ),
		'section'     => 'routine_section_id',
		'row_label' => [
			'type'  => 'field',
			'value' => esc_html__( 'Routine Deatils', 'quanca' ),
			'field' => 'link_text',
		],
		'button_label' => esc_html__("Add Routine Deatils", 'quanca' ),
	
		'settings'    => 'routine_repeater',
		'fields' => [
			'routine_title' => [
				'type'        => 'text',
				'label'       => esc_attr__( 'Name', 'quanca' ),
			],
			'routine_time' => [
				'type'        => 'text',
				'label'       => esc_attr__( 'Time', 'quanca' ),
			],
			'routine_img' => [
				'type'        => 'image',
				'label'       => esc_attr__( 'Image', 'quanca' ),
			],

		],
		'choices' => [
			'limit' => 3
		],
		'active_callback'=>[
            [ 
                'setting' =>'routine_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	Kirki::add_section( 'homeschedule_section_id', array(
		'title'          => esc_html__( 'Schedule Descriptions', 'quanca' ),
		'panel'          => 'home_panel_id',
		'priority'       => 10,
		'active_callback' => function() {
			if(is_page_template('homepage.php')){
				return true;}},
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'homeschedule_setting',
		'label'       => esc_html__( 'Display Schedule Descriptions', 'quanca' ),
		'section'     => 'homeschedule_section_id',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'homeschedule_subtitle_setting',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Schedule Descriptions Section Sub Title', 'quanca' ),
		'section'     => 'homeschedule_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'homeschedule_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
		
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'homeschedule_title_setting',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Schedule Descriptions Section Title', 'quanca' ),
		'section'     => 'homeschedule_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'homeschedule_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
		
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'textarea',
		'settings'    => 'homeschedule_desc_setting',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Schedule Descriptions Section Description', 'quanca' ),
		'section'     => 'homeschedule_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'homeschedule_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
		
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'homeschedule_btn_setting',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Schedule Descriptions Button', 'quanca' ),
		'section'     => 'homeschedule_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'homeschedule_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
		
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'homeschedule_btnlink_setting',
		'label'       => esc_html__( 'Schedule Descriptions Button Link', 'quanca' ),
		'section'     => 'homeschedule_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'homeschedule_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
		
	] );
	
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'image',
		'settings'    => 'homeschedule_img_setting',
		'label'       => esc_html__( 'Schedule Descriptions Section Image', 'quanca' ),
		'section'     => 'homeschedule_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'homeschedule_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
		
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'hometimetable_setting',
		'label'       => esc_html__( 'Display Everydays Contact Time Table', 'quanca' ),
		'description' => esc_html__( 'Note: It was loaded from contact page template because it is same.', 'quanca' ),
		'section'     => 'homeschedule_section_id',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
		'active_callback'=>[
            [ 
                'setting' =>'homeschedule_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );

	Kirki::add_section( 'homework_section_id', array(
		'title'          => esc_html__( 'Work History', 'quanca' ),
		'panel'          => 'home_panel_id',
		'priority'       => 10,
		'active_callback' => function() {
			if(is_page_template('homepage.php')){
				return true;}},
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'homework_setting',
		'label'       => esc_html__( 'Display Work History', 'quanca' ),
		'description' => esc_html__( 'Note: It was loaded from about page template because it is same.', 'quanca' ),
		'section'     => 'homework_section_id',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );

	Kirki::add_section( 'homeextra_section_id', array(
		'title'          => esc_html__( 'Extra post with links', 'quanca' ),
		'panel'          => 'home_panel_id',
		'priority'       => 10,
		'active_callback' => function() {
			if(is_page_template('homepage.php')){
				return true;}},
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'homeextra_setting',
		'label'       => esc_html__( 'Display Extra post', 'quanca' ),
		'section'     => 'homeextra_section_id',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'repeater',
		'label'       => esc_attr__( 'Extra Post', 'quanca' ),
		'section'     => 'homeextra_section_id',
		'row_label' => [
			'type'  => 'field',
			'value' => esc_html__( 'Extra', 'quanca' ),
			'field' => 'link_text',
		],
		'button_label' => esc_html__("Add Extra", 'quanca' ),
	
		'settings'    => 'extra_repeater',
		'fields' => [
			'extra_title' => [
				'type'        => 'text',
				'label'       => esc_attr__( 'Title', 'quanca' ),
			],
			'extra_desc' => [
				'type'        => 'textarea',
				'label'       => esc_attr__( 'Description', 'quanca' ),
			],
			'extra_icon' => [
				'type'        => 'image',
				'label'       => esc_attr__( 'Icon', 'quanca' ),
			],
			'extra_img' => [
				'type'        => 'image',
				'label'       => esc_attr__( 'Image', 'quanca' ),
			],
			'extra_btn' => [
				'type'        => 'text',
				'label'       => esc_attr__( 'Button Title', 'quanca' ),
			],
			'extra_link' => [
				'type'        => 'text',
				'label'       => esc_attr__( 'Button Link', 'quanca' ),
			],

		],
		'choices' => [
			'limit' => 3
		],
		'active_callback'=>[
            [ 
                'setting' =>'homeextra_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );

	Kirki::add_section( 'homeclass_section_id', array(
		'title'          => esc_html__( 'Training Classes', 'quanca' ),
		'panel'          => 'home_panel_id',
		'priority'       => 10,
		'active_callback' => function() {
			if(is_page_template('homepage.php')){
				return true;}},
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'homeclass_setting',
		'label'       => esc_html__( 'Display Classes', 'quanca' ),
		'section'     => 'homeclass_section_id',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'homeclass_subtitle_setting',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Sub Title', 'quanca' ),
		'section'     => 'homeclass_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'homeclass_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
		
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'settings'    => 'homeclass_title_setting',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Title', 'quanca' ),
		'section'     => 'homeclass_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'homeclass_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
		
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'textarea',
		'settings'    => 'homeclass_desc_setting',
		'transport'   => 'postMessage',
		'label'       => esc_html__( 'Description', 'quanca' ),
		'section'     => 'homeclass_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'homeclass_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
		
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'repeater',
		'label'       => esc_attr__( 'Training Classes', 'quanca' ),
		'section'     => 'homeclass_section_id',
		'row_label' => [
			'type'  => 'field',
			'value' => esc_html__( 'Training Class', 'quanca' ),
			'field' => 'link_text',
		],
		'button_label' => esc_html__("Training Class", 'quanca' ),
	
		'settings'    => 'homeclass_repeater',
		'fields' => [
			'class_title' => [
				'type'        => 'text',
				'label'       => esc_attr__( 'Title', 'quanca' ),
			],
			'class_desc' => [
				'type'        => 'text',
				'label'       => esc_attr__( 'Description', 'quanca' ),
			],
			
			'class_img' => [
				'type'        => 'image',
				'label'       => esc_attr__( 'Image', 'quanca' ),
			],
			

		],
		'choices' => [
			'limit' => 8
		],
		'active_callback'=>[
            [ 
                'setting' =>'homeclass_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	Kirki::add_section( 'homesqu_section_id', array(
		'title'          => esc_html__( 'Question & Answer & Owner Details', 'quanca' ),
		'panel'          => 'home_panel_id',
		'priority'       => 14,
		'active_callback' => function() {
			if(is_page_template('homepage.php')){
				return true;}},
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'homesqu_setting',
		'label'       => esc_html__( 'Display Question & Answer', 'quanca' ),
		'section'     => 'homesqu_section_id',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );
	
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'transport'   => 'postMessage',
		'settings'    => 'homesqu_owner_name',
		'label'       => esc_html__( 'Owner Name', 'quanca' ),
		'section'     => 'homesqu_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'homesqu_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
		
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'transport'   => 'postMessage',
		'settings'    => 'homesqu_ownedes',
		'label'       => esc_html__( 'Owner Details', 'quanca' ),
		'section'     => 'homesqu_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'homesqu_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
		
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'image',
		'settings'    => 'homesqu_owner_img',
		'label'       => esc_html__( 'Owner Image', 'quanca' ),
		'section'     => 'homesqu_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'homesqu_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
		
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'transport'   => 'postMessage',
		'settings'    => 'homesqu_title_setting',
		'label'       => esc_html__( 'Question Or Title', 'quanca' ),
		'section'     => 'homesqu_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'homesqu_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
		
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'transport'   => 'postMessage',
		'settings'    => 'homesqu_subtitle_setting',
		'label'       => esc_html__( 'Answer with bold text', 'quanca' ),
		'section'     => 'homesqu_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'homesqu_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
		
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'textarea',
		'transport'   => 'postMessage',
		'settings'    => 'homesqu_ans_setting',
		'label'       => esc_html__( 'Answer', 'quanca' ),
		'section'     => 'homesqu_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'homesqu_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]	
	] );

	Kirki::add_section( 'homeservice_section_id', array(
		'title'          => esc_html__( 'Services', 'quanca' ),
		'panel'          => 'home_panel_id',
		'priority'       => 15,
		'active_callback' => function() {
			if(is_page_template('homepage.php')){
				return true;}},
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'homeservice_setting',
		'label'       => esc_html__( 'Display Service Section', 'quanca' ),
		'section'     => 'homeservice_section_id',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'repeater',
		'label'       => esc_attr__( 'Services', 'quanca' ),
		'section'     => 'homeservice_section_id',
		'row_label' => [
			'type'  => 'field',
			'value' => esc_html__( 'Service', 'quanca' ),
			'field' => 'link_text',
		],
		'button_label' => esc_html__("Add New", 'quanca' ),
	
		'settings'    => 'service_repeater',
		'fields' => [
			'service_icon' => [
				'type'        => 'image',
				'label'       => esc_attr__( 'Icon', 'quanca' ),
			],
			'service_title' => [
				'type'        => 'text',
				'label'       => esc_attr__( 'Title', 'quanca' ),
			],
			'service_desc' => [
				'type'        => 'textarea',
				'label'       => esc_attr__( 'Description', 'quanca' ),
			],

		],
		'choices' => [
			'limit' => 2
		],
		'active_callback'=>[
            [ 
                'setting' =>'homeservice_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'homeserbtn_setting',
		'label'       => esc_html__( 'Display Button', 'quanca' ),
		'section'     => 'homeservice_section_id',
		'default'     => '0',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
		'active_callback'=>[
            [ 
                'setting' =>'homeservice_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'transport'   => 'postMessage',
		'settings'    => 'homebtn_title_setting',
		'label'       => esc_html__( 'Button Title', 'quanca' ),
		'section'     => 'homeservice_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'homeserbtn_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
		
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'transport'   => 'postMessage',
		'settings'    => 'homebtn_link_setting',
		'label'       => esc_html__( 'Button Link', 'quanca' ),
		'section'     => 'homeservice_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'homeserbtn_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
		
	] );

	Kirki::add_section( 'homesblog_section_id', array(
		'title'          => esc_html__( 'Blog', 'quanca' ),
		'panel'          => 'home_panel_id',
		'priority'       => 15,
		'active_callback' => function() {
			if(is_page_template('homepage.php')){
				return true;}},
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'homesblog_setting',
		'label'       => esc_html__( 'Display Blog Section', 'quanca' ),
		'section'     => 'homesblog_section_id',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'textarea',
		'transport'   => 'postMessage',
		'settings'    => 'homesblog_subtitle_setting',
		'label'       => esc_html__( 'Blog Section Description', 'quanca' ),
		'section'     => 'homesblog_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'homesblog_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
		
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'transport'   => 'postMessage',
		'settings'    => 'homesblog_title_setting',
		'label'       => esc_html__( 'Blog Section Title', 'quanca' ),
		'section'     => 'homesblog_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'homesblog_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
		
	] );
	
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'transport'   => 'postMessage',
		'settings'    => 'homesblog_btn_title',
		'label'       => esc_html__( 'Button Title', 'quanca' ),
		'section'     => 'homesblog_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'homesblog_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
		
	] );
	
	Kirki::add_section( 'homesgallery_section_id', array(
		'title'          => esc_html__( 'Gallary', 'quanca' ),
		'panel'          => 'home_panel_id',
		'priority'       => 15,
		'active_callback' => function() {
			if(is_page_template('homepage.php')){
				return true;}},
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'homesgallery_setting',
		'label'       => esc_html__( 'Display Schedule Descriptions', 'quanca' ),
		'section'     => 'homesgallery_section_id',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'text',
		'transport'   => 'postMessage',
		'settings'    => 'homesgallery_title_setting',
		'label'       => esc_html__( 'Gallery Title', 'quanca' ),
		'section'     => 'homesgallery_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'homesgallery_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
		
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'textarea',
		'transport'   => 'postMessage',
		'settings'    => 'homesgallery_subtitle_setting',
		'label'       => esc_html__( 'Gallery Description', 'quanca' ),
		'section'     => 'homesgallery_section_id',
		'active_callback'=>[
            [ 
                'setting' =>'homesgallery_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
		
	] );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'repeater',
		'label'       => esc_attr__( 'Gallery', 'quanca' ),
		'section'     => 'homesgallery_section_id',
		'row_label' => [
			'type'  => 'field',
			'value' => esc_html__( 'Image', 'quanca' ),
			'field' => 'link_text',
		],
		'button_label' => esc_html__("Add Image", 'quanca' ),
	
		'settings'    => 'gallery_repeater',
		'fields' => [
			'gallery_img' => [
				'type'        => 'image',
				'label'       => esc_attr__( 'Image', 'quanca' ),
			],

		],
		'choices' => [
			'limit' => 6
		],
		'active_callback'=>[
            [ 
                'setting' =>'homesgallery_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	Kirki::add_section( 'office_section_id', array(
		'title'          => esc_html__( 'Other Office Address', 'quanca' ),
		'panel'          => 'home_panel_id',
		'priority'       => 15,
		'active_callback' => function() {
			if(is_page_template('homepage.php')){
				return true;}},
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'office_setting',
		'label'       => esc_html__( 'Display Other Office Address', 'quanca' ),
		'section'     => 'office_section_id',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );
	
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'repeater',
		'label'       => esc_attr__( 'Other Office Address', 'quanca' ),
		'section'     => 'office_section_id',
		'row_label' => [
			'type'  => 'field',
			'value' => esc_html__( 'Other Office', 'quanca' ),
			'field' => 'link_text',
		],
		'button_label' => esc_html__("Add Office Address", 'quanca' ),
	
		'settings'    => 'office_repeater',
		'fields' => [
			'office_name' => [
				'type'        => 'text',
				'label'       => esc_attr__( 'Office Name', 'quanca' ),
			],
			'office_address' => [
				'type'        => 'text',
				'label'       => esc_attr__( 'Office Adress', 'quanca' ),
			],
			'office_adress2' => [
				'type'        => 'text',
				'label'       => esc_attr__( 'Office Adress', 'quanca' ),
			],
			'division' => [
				'type'        => 'text',
				'label'       => esc_attr__( 'Division', 'quanca' ),
			],
			'phnnumber' => [
				'type'        => 'text',
				'label'       => esc_attr__( 'Phone Number', 'quanca' ),
			],
			
		],
		'choices' => [
			'limit' => 4
		],
		'active_callback'=>[
            [ 
                'setting' =>'office_setting',
                'operator' => '==',
                'value'  => true,
            ]
        ]
	] );
	/** Footer */
	Kirki::add_panel( 'footer_panel_id', array(
		'priority'    => 1000,
		'title'       => esc_html__( 'Footer', 'quanca' ),
		
	) );
	Kirki::add_section( 'footer_section_id', array(
		'title'          => esc_html__( 'Logo', 'quanca' ),
		'description'    => esc_html__( 'Display Logo', 'quanca' ),
		'panel'          => 'footer_panel_id',
		'priority'       => 10,
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'footer_logo_stting',
		'label'       => esc_html__( 'Display Logo', 'quanca' ),
		'section'     => 'footer_section_id',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );
	Kirki::add_section( 'footer_social_id', array(
		'title'          => esc_html__( 'Social Profile', 'quanca' ),
		'description'    => esc_html__( 'Display Social Profile', 'quanca' ),
		'panel'          => 'footer_panel_id',
		'priority'       => 10,
	) );
	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'footer_social_stting',
		'label'       => esc_html__( 'Display Social Profile', 'quanca' ),
		'section'     => 'footer_social_id',
		'default'     => '1',
		'choices'     => [
			'on'  => esc_html__( 'Display', 'quanca' ),
			'off' => esc_html__( 'Hide', 'quanca' ),
		],
	] );
	/**end footer */


Kirki::add_panel( 'panel_id', array(
    'priority'    => 10,
    'title'       => esc_html__( 'Class Page Customize', 'quanca' ),
	
) );
Kirki::add_section( 'section_id', array(
    'title'          => esc_html__( 'My Section', 'quanca' ),
    'description'    => esc_html__( 'My section description.', 'quanca' ),
    'panel'          => 'panel_id',
    'priority'       => 160,
	'active_callback' => function() {
		if(is_page_template('about.php')){
			return true;}},
) );
Kirki::add_field( 'theme_config_id', [
	'type'        => 'image',
	'settings'    => 'image_setting_url',
	'label'       => esc_html__( 'Image Control (URL)', 'quanca' ),
	'description' => esc_html__( 'Description Here.', 'quanca' ),
	'section'     => 'section_id',
] );
};














function my_register_blogname_partials( WP_Customize_Manager $wp_customize ) {

    // Abort if selective refresh is not available.
    if ( ! isset( $wp_customize->selective_refresh ) ) {
        return;
    }
	$wp_customize->selective_refresh->add_partial( 'document_title', [
        'selector'        => '#footer_logo',
        'settings'        => [ 'footer_logo_stting' ],
        'render_callback' => function(){
			return get_theme_mod( 'footer_logo_stting');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'footer_social', [
        'selector'        => '.footer-social',
        'settings'        => [ 'footer_social_stting' ],
        'render_callback' => function(){
			return get_theme_mod( 'footer_social_stting');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'header_top', [
        'selector'        => '.header-top',
        'settings'        => [ 'header_top_setting' ],
        'render_callback' => function(){
			return get_theme_mod( 'header_top_setting');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'header_button', [
        'selector'        => '.header-button',
        'settings'        => [ 'header_button_setting' ],
        'render_callback' => function(){
			return get_theme_mod( 'header_button_setting');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'class_page_header', [
        'selector'        => '.class-page-header',
        'settings'        => [ 'class_background_setting' ],
        'render_callback' => function(){
			return get_theme_mod( 'class_background_setting');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'class_page_title', [
        'selector'        => '.class_title',
        'settings'        => [ 'class_page_title' ],
        'render_callback' => function(){
			return get_theme_mod( 'class_page_title');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'class_page_descrip', [
        'selector'        => '.class_desc',
        'settings'        => [ 'class_page_desc' ],
        'render_callback' => function(){
			return get_theme_mod( 'class_page_desc');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'schedule_page_header', [
        'selector'        => '.schedule-page-header',
        'settings'        => [ 'schedule_background_setting' ],
        'render_callback' => function(){
			return get_theme_mod( 'schedule_background_setting');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'schedule_page_title', [
        'selector'        => '.schedule_title',
        'settings'        => [ 'schedule_page_title' ],
        'render_callback' => function(){
			return get_theme_mod( 'schedule_page_title');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'schedule_page_descrip', [
        'selector'        => '.schedule_desc',
        'settings'        => [ 'schedule_page_desc' ],
        'render_callback' => function(){
			return get_theme_mod( 'schedule_page_desc');
		},
	] );
	
	$wp_customize->selective_refresh->add_partial( 'index_page_header', [
        'selector'        => '.index-page-header',
        'settings'        => [ 'index_background_setting' ],
        'render_callback' => function(){
			return get_theme_mod( 'index_background_setting');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'index_page_title', [
        'selector'        => '.index_title',
        'settings'        => [ 'index_page_title' ],
        'render_callback' => function(){
			return get_theme_mod( 'index_page_title');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'index_page_descrip', [
        'selector'        => '.index_desc',
        'settings'        => [ 'index_page_desc' ],
        'render_callback' => function(){
			return get_theme_mod( 'index_page_desc');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'schedule_page_img_sunday', [
        'selector'        => '#sunday',
        'settings'        => [ 'schedule_sunday_img' ],
        'render_callback' => function(){
			return get_theme_mod( 'schedule_sunday_img');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'schedule_page_img_monday', [
        'selector'        => '#monday',
        'settings'        => [ 'schedule_monday_img' ],
        'render_callback' => function(){
			return get_theme_mod( 'schedule_monday_img');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'schedule_page_img_tuesday', [
        'selector'        => '#tuesday',
        'settings'        => [ 'schedule_tuesday_img' ],
        'render_callback' => function(){
			return get_theme_mod( 'schedule_tuesday_img');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'schedule_page_img_wednesday', [
        'selector'        => '#wednesday',
        'settings'        => [ 'schedule_wednesday_img' ],
        'render_callback' => function(){
			return get_theme_mod( 'schedule_wednesday_img');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'schedule_page_img_thursday', [
        'selector'        => '#thursday',
        'settings'        => [ 'schedule_thursday_img' ],
        'render_callback' => function(){
			return get_theme_mod( 'schedule_thursday_img');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'schedule_page_img_saturday', [
        'selector'        => '#saturday',
        'settings'        => [ 'schedule_saturday_img' ],
        'render_callback' => function(){
			return get_theme_mod( 'schedule_saturday_img');
		},
	] );

	$wp_customize->selective_refresh->add_partial( 'about_banner', [
        'selector'        => '.banner-cust',
        'settings'        => [ 'about_banner_img' ],
        'render_callback' => function(){
			return get_theme_mod( 'about_banner_img');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'about_team_member', [
        'selector'        => '.team_member',
        'settings'        => [ 'team_stting' ],
        'render_callback' => function(){
			return get_theme_mod( 'team_stting');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'about_vid', [
        'selector'        => '.about_vid',
        'settings'        => [ 'about_vid_stting' ],
        'render_callback' => function(){
			return get_theme_mod( 'about_vid_stting');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'about_qu_ans', [
        'selector'        => '.about_qu_ans',
        'settings'        => [ 'about_qu_desc_stting' ],
        'render_callback' => function(){
			return get_theme_mod( 'about_qu_desc_stting');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'training_desc', [
        'selector'        => '.training_desc',
        'settings'        => [ 'about_training_small_title' ],
        'render_callback' => function(){
			return get_theme_mod( 'about_training_small_title');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'work_his', [
        'selector'        => '.work_his',
        'settings'        => [ 'about_workhistory_stting' ],
        'render_callback' => function(){
			return get_theme_mod( 'about_workhistory_stting');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'about_descr', [
        'selector'        => '.about_descr',
        'settings'        => [ 'about_des_big_title' ],
        'render_callback' => function(){
			return get_theme_mod( 'about_des_big_title');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'contact_edit', [
        'selector'        => '.contact_edit',
        'settings'        => [ 'contact_title' ],
        'render_callback' => function(){
			return get_theme_mod( 'contact_title');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'head_side', [
        'selector'        => '.sidebar_cont',
        'settings'        => [ 'header_sidebar_img' ],
        'render_callback' => function(){
			return get_theme_mod( 'header_sidebar_img');
		},
	] );

	$wp_customize->selective_refresh->add_partial( 'daily_routine_hm', [
        'selector'        => '.daily_routine_hm',
        'settings'        => [ 'routine_setting' ],
        'render_callback' => function(){
			return get_theme_mod( 'routine_setting');
		},
	] );
	
	$wp_customize->selective_refresh->add_partial( 'timetable', [
        'selector'        => '#timetable',
        'settings'        => [ 'homeschedule_setting' ],
        'render_callback' => function(){
			return get_theme_mod( 'homeschedule_setting');
		},
	] );
	$wp_customize->selective_refresh->add_partial( 'workhistory', [
        'selector'        => '#workhistory',
        'settings'        => [ 'homework_setting' ],
        'render_callback' => function(){
			return get_theme_mod( 'homework_setting');
		},
	] );
$wp_customize->selective_refresh->add_partial( 'hm-extra', [
        'selector'        => '#hm-extra',
        'settings'        => [ 'homeextra_setting' ],
        'render_callback' => function(){
			return get_theme_mod( 'homeextra_setting');
		},
	] );
$wp_customize->selective_refresh->add_partial( 'homeclass', [
        'selector'        => '#homeclass',
        'settings'        => [ 'homeclass_setting' ],
        'render_callback' => function(){
			return get_theme_mod( 'homeclass_setting');
		},
	] );
$wp_customize->selective_refresh->add_partial( 'hq-qu-ans', [
        'selector'        => '#hq-qu-ans',
        'settings'        => [ 'homesqu_setting' ],
        'render_callback' => function(){
			return get_theme_mod('homesqu_setting');
		},
	] );
$wp_customize->selective_refresh->add_partial( 'service-hm', [
        'selector'        => '#service-hm',
        'settings'        => [ 'homeservice_setting' ],
        'render_callback' => function(){
			return get_theme_mod( 'homeservice_setting');
		},
	] );
$wp_customize->selective_refresh->add_partial( 'hm-blog', [
        'selector'        => '#hm-blog',
        'settings'        => [ 'homesblog_setting' ],
        'render_callback' => function(){
			return get_theme_mod( 'homesblog_setting');
		},
	] );
$wp_customize->selective_refresh->add_partial( 'hm-gallery', [
        'selector'        => '#hm-gallery',
        'settings'        => [ 'homesgallery_setting' ],
        'render_callback' => function(){
			return get_theme_mod( 'homesgallery_setting');
		},
	] );
$wp_customize->selective_refresh->add_partial( 'office_setting', [
        'selector'        => '#office_setting',
        'settings'        => [ 'office_setting' ],
        'render_callback' => function(){
			return get_theme_mod( 'office_setting');
		},
	] );

}
add_action( 'customize_register', 'my_register_blogname_partials' );
?>