<?php 
function ocdi_import_files() {
	return array(
		array(
			'import_file_name'             => 'Demo Import',
			'local_import_file'            => trailingslashit( get_template_directory() ) . 'inc/demo/demo-content.xml',
			'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'inc/demo/widgets.wie',
			'local_import_customizer_file' => trailingslashit( get_template_directory() ) . 'inc/demo/customizer.dat',
			
        ),
    );
		
}
add_filter( 'ocdi/import_files', 'ocdi_import_files' );