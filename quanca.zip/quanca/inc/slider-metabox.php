<?php
// Post-Type = Schedule
if( class_exists( 'CSF' ) ) {

  //
  // Set a unique slug-like ID
  $prefix = 'my_slider_options';

  //
  // Create a metabox
  CSF::createMetabox( $prefix, array(
    'title'     => 'My Slider Options',
    'post_type' => 'slider',
  ) );

  //
  // Create a section
    CSF::createSection( $prefix, array(
                'title'     => 'Add Slider Extra',
                'fields'    => array(
                    array(
                        'id'    => 'slide-img',
                        'type'  => 'upload',
                        'title' => 'Slider Image'
                    ),
                    array(
                        'id'    => 'slide-button',
                        'type'  => 'text',
                        'title' => 'Button Title'
                    ),
                    array(
                        'id'    => 'slide-btn-link',
                        'type'  => 'text',
                        'title' => 'Button Link'
                    ),
                )
            ),
        );
}
