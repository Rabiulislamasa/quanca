<?php get_header('single');?>
<section class="content-section" id="eror_sec_bg" style="background-image: url('<?php echo get_template_directory_uri()?>./assets/images/404.jpg ')">
  
</section>
<?php get_footer();?>