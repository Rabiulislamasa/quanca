<?php if(get_theme_mod('homeclass_setting', true ) == true): ?>
<section class="content-section">
  <div class="container">
    <div class="row" id="homeclass">
      <div class="col-12">
        <div class="section-title wow fade" >
        <?php if(has_site_icon()):?>
            <figure><img src="<?php echo esc_url(site_icon_url());?>" alt="Image"></figure>
          <?php endif;?>
		<h6 id="homeclass_subtitle_setting"><?php echo get_theme_mod('homeclass_subtitle_setting'); ?></h6>
          <h2 id="homeclass_title_setting"><?php echo get_theme_mod('homeclass_title_setting'); ?></h2>
          <p id="homeclass_desc_setting"><?php echo get_theme_mod('homeclass_desc_setting'); ?></p>
        </div>
        <!-- end section-title --> 
      </div>
      <!-- end col-12 --> 
		<div class="col-12">
		<div class="carousel-classes">
			<div class="swiper-wrapper">
				<?php 
					$get_classes = get_theme_mod('homeclass_repeater');
					if($get_classes):
						foreach($get_classes as $get_class):
				?>
				<div class="swiper-slide">
					<div class="class-box">
						<figure class="wow reveal-effect">
					<a href="#"><img id="training_class_img" src="<?php echo wp_get_attachment_url($get_class['class_img']);?>" alt="Image"></a>
					</figure>
					<h6><?php echo esc_html(strtoupper($get_class['class_title'])); ?></h6>
					<small><?php echo esc_html($get_class['class_desc']) ?></small>
						</div>
					<!-- end class-box -->
						</div>
						<!-- end swiper-slide -->
				<?php endforeach; endif;?>
				</div>
				

			<!-- end swiper-wrapper -->
			<div class="swiper-pagination"></div>
			<!-- end swiper-pagination -->
			</div>
			<!-- end carousel-classes -->
		</div>
		<!-- end col-12 -->
    </div>
    <!-- end row -->
  </div>
  <!-- end container --> 
</section>
<!-- end content-section -->
<?php endif;?>