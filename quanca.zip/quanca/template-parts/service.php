<?php if(get_theme_mod('homeservice_setting', true ) == true): ?>
<section class="content-section" data-background="#0d0d0d">
  <div class="container">
    <div class="row no-gutters" id="service-hm">
    <?php
      $services = get_theme_mod('service_repeater');
      if($services):
        foreach($services as $service):
    ?>
      <div class="col-lg-6">
        <div class="pass-box wow fade">
          <figure> <img src="<?php echo wp_get_attachment_url($service['service_icon']) ;?>" alt="Image"></figure>
          <h6><?php echo esc_html($service['service_title']);?></h6>
          <p><?php echo esc_html($service['service_desc']);?></p>
        </div>
        <!-- end pass-box --> 
      </div>
      <!-- end col-6 -->
      <?php endforeach; endif; ?>
      <?php if(get_theme_mod('homeserbtn_setting', true ) == true): ?>
      <div class="col-12 text-center">
        <a href="<?php echo get_theme_mod('homebtn_link_setting') ?>" class="custom-button" id="homebtn_title_setting"><?php echo get_theme_mod('homebtn_title_setting') ?></a>
      </div>
      <?php endif; ?>
      <!-- end col-12 --> 
    </div>
    <!-- end row --> 
  </div>
  <!-- end container --> 

</section>
<?php endif; ?>