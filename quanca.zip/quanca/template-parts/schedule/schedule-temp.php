            <?php
                $my_schedule = get_post_meta( $post->ID,'my_schedule_options', true);
                $from = $my_schedule['schedule-from'];
                $to = $my_schedule['schedule-to'];
                $desc = $my_schedule['schedule-desc'];
                
            ?>
              <li>
                <span><?php echo esc_html($from);?> <?php _e('-','quanca');?> <?php echo esc_html($to);?></span>
                <h6><?php the_title();?></h6>
                <small><?php echo esc_html($desc);?> </small> 
              </li> 