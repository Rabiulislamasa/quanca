<header class="slider" id="slide_height">
	<div class="main-slider" id="slide_height_two">
    <div class="swiper-wrapper">
    
    <?php 
      
			$slide_args = array( 'post_type' => 'slider', 'posts_per_page' => 5 );
			$sliders = new WP_Query( $slide_args ); 
      if($sliders->have_posts()) :
        while($sliders->have_posts()):
          $sliders->the_post();
          $my_slider = get_post_meta( $post->ID,'my_slider_options', true);
          $slide_bg = $my_slider['slide-img'];
          $slide_img = wp_get_attachment_image_src($slide_bg,'full');
          $slide_btn = $my_slider['slide-button'];
          $slide_link = $my_slider['slide-btn-link'];
      ?>
      <div class="swiper-slide">
        <div class="slide-image" style="background-image: url(<?php echo esc_url( $slide_bg); ?>);"></div>
        <!-- end slider-image -->
          <div class="container">
            <h1><?php the_title();?></h1>
            <p><?php the_excerpt(); ?></p>
            <a href="<?php echo esc_url($slide_link);?>"><?php echo esc_html($slide_btn);?></a>
          </div>
        <!-- end container --> 
      </div>
      <?php endwhile;?>
		  <?php wp_reset_postdata(); ?>
      <?php endif;?>
    </div>
    <!-- end swiper-wrapper -->
    <div class="button-prev"><i class="lni lni-chevron-left"></i></div>
    <!-- end button-prev -->
    <div class="button-next"><i class="lni lni-chevron-right"></i></div>
    <!-- end button-next -->
    <div class="swiper-pagination"></div>
    <!-- end swiper-pagination -->
  </div>
  <!-- end main-slider --> 
</header>
<!-- end slider -->