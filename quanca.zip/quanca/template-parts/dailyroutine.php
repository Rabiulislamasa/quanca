
<?php if(get_theme_mod('routine_setting', true ) == true): ?>
<section class="content-section">
  <div class="container">
    <div class="row daily_routine_hm">
      <div class="col-12">
        <div class="section-title wow fade">
        <?php if(has_site_icon()):?>
            <figure><img src="<?php echo esc_url(site_icon_url());?>" alt="Image"></figure>
          <?php endif;?>
        <h2 id="routine_title_setting"><?php echo strtoupper(get_theme_mod('routine_title_setting'))?></h2>
          <p id="routine_desc_setting"><?php echo get_theme_mod('routine_desc_setting')?></p>
        </div>
        <!-- end section-title --> 
      </div>
      <!-- end col-12 --> 
    </div>
    <!-- end row -->
    <div class="row justify-content-center">
    <?php  
      $routines = get_theme_mod('routine_repeater');
      if($routines):
        foreach($routines as $routine):
        $routine_name = strtoupper($routine['routine_title']);
    ?>
      <div class="col-lg-4 col-md-6">
        <div class="image-box">
          <figure class="wow reveal-effect" id="img_sizing"><img src="<?php echo wp_get_attachment_url( $routine['routine_img']) ?>" alt="Image" class="routine-img"></figure>
          <span class="time"><?php echo esc_html($routine['routine_time']) ?> <?php _e("-","quanca"); ?> </span>
          <h6><?php echo esc_html($routine_name) ?></h6>
        </div>
        <!-- end image-box --> 
      </div>
      <!-- end col-4 -->
    <?php endforeach;endif;?>
    </div>
    <!-- end row --> 
  </div>
  <!-- end container --> 
</section>
<?php endif; ?>