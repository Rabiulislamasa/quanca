<?php if(get_theme_mod('homeextra_setting', true ) == true): ?>
<section class="content-section no-spacing">
  <div class="container-fluid no-spacing" >
    <div class="row no-gutters ">
    <?php 
      $get_datas = get_theme_mod('extra_repeater');
      if($get_datas):
        foreach($get_datas as $get_data):
    ?>
      <div class="col-lg-4 ">
        <div class="image-overlap-box wow fade">
          <figure> <img src="<?php echo wp_get_attachment_url( $get_data['extra_img']); ?>" alt="Image"> </figure>
          <div class="content"> <img src="<?php echo wp_get_attachment_url($get_data['extra_icon']); ?>" alt="Image">
            <h6><?php wp_kses_post($get_data['extra_title']); ?></h6>
            <p><?php wp_kses_post($get_data['extra_desc']); ?></p>
            <a href="<?php wp_kses_post($get_data['extra_link']); ?>"><?php wp_kses_post($get_data['extra_btn']); ?></a> </div>
          <!-- end content --> 
        </div>
        <!-- end image-overlap-box --> 
      </div>
      
  <div id="hm-extra"></div>
      <!-- end col-4 -->
    <?php endforeach;endif; ?>
    </div>
  </div>
  <!-- end container-fluid --> 
</section>
<?php endif; ?>
<!-- end content-section -->