<div class="col-lg-6">
        <figure class="side-image full-right wow reveal-effect " id="time_bg">
        
      <?php if(get_theme_mod('hometimetable_setting', true ) == true): ?>
          <ul class="side-timetable">
            <?php
              $time_days = get_theme_mod('time_repeater');
              
              if($time_days):
                foreach( $time_days as $time_day):
            ?>
                <li><span><?php echo strtoupper($time_day['contact_day']);?></span><b><?php echo strtoupper($time_day['contact_from']);?> <?php _e('-','quanca');?> <?php echo strtoupper($time_day['contact_to']);?></b></li>
              <?php endforeach;endif; ?>
              </ul>
				<?php endif;?>
          <img src="<?php echo  get_theme_mod('homeschedule_img_setting') ?>" alt="Image">
        </figure>
      </div>