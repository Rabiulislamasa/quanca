<?php if(get_theme_mod('office_setting', true ) == true): ?>
<section class="content-section"> 
	<div class="container">
		<div class="row" id="office_setting">
			<?php
				$adresss = get_theme_mod('office_repeater');
				if($adresss):
					foreach($adresss as $adress):
			?>
			<div class="col-lg-3 col-md-6">
				<div class="branch-box wow fade">
					<h6><?php echo esc_html($adress['office_name']); ?> </h6>
					<address><?php echo esc_html($adress['office_address']); ?><br>
					<?php echo esc_html($adress['office_adress2']); ?><br>
					<b><?php echo esc_html($adress['division']); ?></b>
					</address>
					<a href="#"><?php echo esc_html($adress['phnnumber']); ?></a>
				</div>
				<!-- end branch-box -->
				
			</div>
			<?php endforeach;
				endif;
			?>
			<!-- end row --> 
		</div>
    </div>
</section>
<?php endif; ?>