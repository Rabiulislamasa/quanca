<?php if(get_theme_mod('homesgallery_setting', true ) == true): ?>

<section class="content-section" data-background="#f42828"> 
	 <div class="container">
    <div class="row align-items-center" id="hm-gallery">
      <div class="col-lg-6">
		  <div class="side-content light  wow fade">
		    <h2 id="homesgallery_title_setting"><?php echo get_theme_mod('homesgallery_title_setting');?></h2>
			  <h6 id="homesgallery_subtitle_setting"><?php echo get_theme_mod('homesgallery_subtitle_setting');?></h6>
		  </div>
		  <!-- end side-content -->
	</div>
      <!-- end col-6 --> 
		<div class="col-lg-6">
		<div class="side-gallery">
				<?php 
					$images =  get_theme_mod('gallery_repeater');
					if($images):
						foreach($images as $image):
				?>
				<figure class="gallery_a">
					<a href="<?php echo wp_get_attachment_url($image['gallery_img']) ?>" data-fancybox class="wow reveal-effect">
					<img src="<?php echo wp_get_attachment_url($image['gallery_img']) ?>" alt="Image"></a>
				</figure>
				<?php endforeach; endif;?>
			</div>
			<!-- end side-gallery -->
	</div>
      <!-- end col-6 --> 
    </div>
    <!-- end row --> 
  </div>
  <!-- end container --> 
	</section>
	<?php endif;?>