
<?php if(get_theme_mod('homeschedule_setting', true ) == true): ?>
  <section class="content-section" data-background="#fafafa">
  <div class="container">
    <div class="row align-items-center no-gutters" id="timetable">
      <div class="col-lg-6">
        <div class="side-content left wow fade">
          <h6 id="homeschedule_subtitle_setting"><?php echo get_theme_mod('homeschedule_subtitle_setting'); ?></h6>
          <h2 id="homeschedule_title_setting"><?php echo get_theme_mod('homeschedule_title_setting'); ?></h2>
          <p id="homeschedule_desc_setting"><?php echo get_theme_mod('homeschedule_desc_setting'); ?></p>
          <a id="homeschedule_btn_setting" href="<?php echo get_theme_mod('homeschedule_btnlink_setting'); ?>" class="custom-button"><?php echo get_theme_mod('homeschedule_btn_setting'); ?></a> </div>
        <!-- end side-content --> 
      </div>
      <!-- end col-6 -->
      <?php get_template_part('template-parts/opentime')?>
      <!-- end col-6 --> 
    </div>
    <!-- end row --> 
  </div>
  <!-- end container --> 
</section>
<?php endif; ?>