
<?php if(get_theme_mod('homework_setting', true ) == true): ?>
<section class="content-section" data-background="#fafafa">
  <div class="container">
    <div class="row justify-content-center" id="workhistory">
    <?php
      $settings = get_theme_mod( 'my_work_repeater'); 

      ?>

    <?php if($settings):?>
    <?php foreach($settings as $setting): 
      
      if ( ! wp_attachment_is_image( $setting['work_icon'] ) ){

      $img_url = esc_url_raw($setting['work_icon']);

      } else {

      $img_url = wp_get_attachment_url($setting['work_icon']);
      }
  ?>
      <div class="col-lg-4 col-md-6" >
        <div class="counter-box wow fade">

          <figure>
          <img src="<?php echo esc_url($img_url) ?>" alt="Image">
          
          </figure>
          <span class="odometer" data-count="<?php echo esc_attr($setting['work_number']);?>" data-status="yes">0</span>
          <h6><?php echo esc_html($setting['work_title']); ?></h6>
        </div>
        <!-- end counter-box --> 
      </div>
    <?php endforeach;?>
    <?php endif;?>
      <!-- end col-4 --> 
    </div>
    <!-- end row --> 
  </div>
  <!-- end container --> 
</section>
<?php endif; ?>