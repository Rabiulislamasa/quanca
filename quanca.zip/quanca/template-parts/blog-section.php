<?php if(get_theme_mod('homesblog_setting', true ) == true): ?>
<section class="content-section">
  <div class="container">
    <div class="row">
      <div class="col-12" id="hm-blog">
        <div class="section-title wow fade">
          <?php if(has_site_icon()):?>
            <figure><img src="<?php echo esc_url(site_icon_url());?>" alt="Image"></figure>
          <?php endif;?>
        <h6 id="homesblog_subtitle_setting"><?php echo get_theme_mod('homesblog_subtitle_setting');?></h6>
          <h2 id="homesblog_title_setting"><?php echo get_theme_mod('homesblog_title_setting');?></h2>
        </div>
        <!-- end section-title --> 
      </div>
      <!-- end col-12 --> 
    </div>
    <!-- end row -->
    <div class="row justify-content-center">
        <?php $posts_arg = array(
            'post_type' => 'post',
            'posts_per_page'=> 3,
            );
            $posts_post = new WP_Query($posts_arg);
          ?>
            <ul>
            <?php 
            if($posts_post->have_posts()) :
			        while($posts_post->have_posts()):
				        $posts_post->the_post();
            ?>
        <div class="col-lg-4 col-md-6 float-left">
          <div class="recent-news">
            <figure class="wow reveal-effect " id="blog-img"><?php if ( has_post_thumbnail() ) { 
                the_post_thumbnail( ); 
              }?></figure>
            <div class="content">
              <h3><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h3>
              <p><?php the_excerpt(); ?></p>
              <small><?php the_tags('',','); ?><span></span><?php the_date(); ?></small> </div>
          </div>
        </div>
      <?php endwhile;?>
		<?php wp_reset_postdata(); ?>
        <?php endif;?>
      <div class="col-12 text-center btn-height-fix"> 
        <a href="<?php echo get_permalink( get_option( 'page_for_posts' ) ); ?>" class="custom-button" id="homesblog_btn_title">
          <?php echo get_theme_mod('homesblog_btn_title');?>
        </a> 
      </div>
      <!-- end col-12 --> 
    </div>
    <!-- end row --> 
  </div>
  <!-- end container --> 
</section>
<!-- end content-section -->
<?php endif; ?>