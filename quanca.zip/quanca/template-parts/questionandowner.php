<?php if(get_theme_mod('homesqu_setting', true ) == true): ?>
<section class="content-section bottom-dark-spacing" data-background="#fafafa">
  <div class="container">
    <div class="row"  id="hq-qu-ans">
      <div class="col-lg-6 height_control">
        <figure class="side-member wow reveal-effect"> 
        <img src="<?php echo get_theme_mod('homesqu_owner_img')?>" alt="Image">
          <figcaption>
            <h5 id="homesqu_owner_name"><?php echo get_theme_mod('homesqu_owner_name');?></h5>
            <span id="homesqu_ownedes"><?php echo get_theme_mod('homesqu_ownedes');?></span> </figcaption>
        </figure>
        <!-- end side-member --> 
      </div>
      <!-- end col-6 -->
      <div class="col-lg-6">
        <div class="side-content right wow fade">
          <h2 id="homesqu_title_setting"><?php echo get_theme_mod('homesqu_title_setting');?></h2>
          <h6 id="homesqu_subtitle_setting"><?php echo get_theme_mod('homesqu_subtitle_setting');?></h6>
          <p id="homesqu_ans_setting"><?php echo get_theme_mod('homesqu_ans_setting');?></p>
          
        </div>
        <!-- end side-member-info --> 
      </div>
      <!-- end col-6 --> 
    </div>
    <!-- end row --> 
  </div>
  <!-- end container --> 
</section>
<!-- end content-section -->
<?php endif; ?>