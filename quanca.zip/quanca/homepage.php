<?php /* Template Name: Homepage Template */ ?>
<?php get_header();?>
<?php get_template_part('template-parts/slider');?>
<?php get_template_part('template-parts/dailyroutine');?>
<?php get_template_part('template-parts/timetable');?>
<?php get_template_part('template-parts/workhistory');?>
<?php get_template_part('template-parts/extra');?>
<?php get_template_part('template-parts/someclass');?>
<?php get_template_part('template-parts/questionandowner');?>
<?php get_template_part('template-parts/service');?>
<?php get_template_part('template-parts/blog-section');?>
 <?php get_template_part('template-parts/sidegallery');?>
<?php get_template_part('template-parts/office-address');?>
<?php get_footer();?>